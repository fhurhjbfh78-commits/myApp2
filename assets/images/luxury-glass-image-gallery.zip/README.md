# UI/UX Demo Project

This project demonstrates a modern, responsive static website with two-language support (Arabic RTL and English LTR). It includes a themed UI, interactive components, and placeholder images.

## Project Structure

- index.html: Main entry point with semantic HTML and RTL/LTR support.
- assets/css/style.css: Global styles with CSS variables and responsive design.
- assets/js/main.js: Core UI interactions, theming, and language switching logic.
- assets/js/lang.js: Language dictionary for AR and EN texts.
- assets/images/: Placeholder images for gallery, hero, and favicon.
- README.md: Documentation for setup, translation, and deployment.

## How to Add Images
- Place your images in assets/images/ and reference them in HTML/CSS.
- Placeholder images are provided and marked as placeholders in the file list.

## How to Change Text
- Text content is driven by the language dictionary in assets/js/lang.js.
- Switch language via the language switch button in the header. The system updates the UI dynamically.

## How Language Switching Works
- The script maintains a currentLang value (ar or en).
- Clicking the language button toggles the language and stores the choice in localStorage.
- All elements with data-i18n attributes are updated from the dictionary.

## How to Customize the Design
- Update CSS variables in assets/css/style.css for colors and spacings.
- Adjust typography and spacings in the same file.
- Add or modify sections in index.html to fit your content.

## How to Deploy
- Netlify: Push to a Git repository and connect to Netlify.
- Vercel: Deploy as static site from a Git repository.
- GitHub Pages: Enable Pages for the main branch or gh-pages.

